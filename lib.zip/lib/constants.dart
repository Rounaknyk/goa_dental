import 'package:flutter/material.dart';

final kPrimaryColour = Colors.blue;
final String kRupee = '₹';
final kBigText = TextStyle(fontSize: 34, fontWeight: FontWeight.bold,);
final kPrimaryColor = Colors.blue;
final kSecondaryColor = Color(0xFF28294A);
final kBackgroundColor = Color(0xFFF4F4F4);
final kButtonBlue = Colors.blue;
final kGrey = Colors.black.withOpacity(0.6);
final clinicNumber = "+919322942635";
final kReviewLink = 'https://www.google.com/search?q=goa+dental+solutions+goa&oq=goa+dental+solutions+goa&gs_lcrp=EgZjaHJvbWUyBggAEEUYOTIGCAEQRRg8MgYIAhBFGDwyBggDEEUYPNIBCDU1MjVqMGoxqAIAsAIA&sourceid=chrome&ie=UTF-8#lrd=0x3bbfb4189bfffff1:0x83e97845f8b5922f,3,,,,';
final messagingServerKey = 'AAAADrWH5Qk:APA91bFEUHXmo5TTzmw6qA3CfiUqYbjBoQrJhpGvH0SKwP_O1divGjW6T4Y3vbwBs1THs7UAOXbl0u7OqUY3wXxip8zkpxO-4ftC4A_DJx1i01YVAUZo0CVGbNq2o7MhD-4t2XQqqCTh';
final diseaseList = [
  'Diabetes',
  'Hypertension (High Blood Pressure)',
  'Cardiovascular Diseases',
  'Asthma',
  'Arthritis',
  'Cancer',
  "Alzheimer's Disease",
  'Depression',
  'Chronic Obstructive Pulmonary Disease (COPD)',
  'Gastrointestinal Disorders',
  'Osteoporosis',
  'Thyroid Disorders',
  'Allergies',
  'Migraine',
  'Infectious Diseases',
];
