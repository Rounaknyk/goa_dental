class PreModel{
  String title, des, preId;
  bool isChecked;

  PreModel({required this.title, required this.des, this.isChecked = false, required this.preId});
}