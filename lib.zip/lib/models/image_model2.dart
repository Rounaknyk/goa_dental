import 'package:flutter/material.dart';
import 'dart:io';

class ImageModel2{
  String description;
  File file;

  ImageModel2({this.description = '', required this.file});
}