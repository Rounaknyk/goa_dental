class NewPlanHistory{

  String date;
  List<String> diseases = [];

  NewPlanHistory({required this.date, required this.diseases});
}