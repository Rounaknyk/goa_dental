class NewMedHistory{

  String time, time2;
  String disease;

  NewMedHistory({required this.time, required this.disease, this.time2 = ''});
}