class DoctorModel{

  String name, uid;

  DoctorModel({required this.name, required this.uid});
}