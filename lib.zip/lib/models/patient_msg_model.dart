class PatientMsgModel {
  String msg, msgId, docUid, docName;

  PatientMsgModel({required this.msg, required this.msgId, required this.docName, required this.docUid});

}