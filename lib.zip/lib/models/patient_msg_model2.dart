class PatientMsgModel2 {
  String msg, msgId, docUid, docName, date, week, time;

  PatientMsgModel2({required this.msg, required this.msgId, required this.docName, required this.docUid, required this.date, required this.time, required this.week});

}