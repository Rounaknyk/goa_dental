import 'package:syncfusion_flutter_calendar/calendar.dart';

class MeetingDataSource extends CalendarDataSource{

  MeetingDataSource(List<Appointment> source){
    appointments = source;
  }

}